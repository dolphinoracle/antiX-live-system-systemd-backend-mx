# antiX-live-system-systemd-backed-mx

experimental systemd units for certain antiX-live-system components
